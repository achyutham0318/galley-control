---
name: Precision Slate
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d5e3fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#3f4850'
  inverse-surface: '#233144'
  inverse-on-surface: '#eaf1ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d5e3fc'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
---

## Brand & Style

This design system embodies high-utility modern minimalism, combining rigorous ergonomics with precise optical hierarchy. Built for high-cognitive-throughput applications, operational cockpits, and modern SaaS platforms, the interface prioritizes data clarity and immediate comprehension over decorative flourish.

### Emotional Profile
- **Engineered Clarity:** The UI feels calibrated, reliable, and noise-free. Content is the interface.
- **Quiet Authority:** Restrained structural frames, quiet dividing planes, and unpolluted whitespace evoke institutional confidence.
- **Dynamic Responsiveness:** Status signals are distinct and legible at a glance, delivering clear operational feedback without visual chaos.

### Design Direction: Architectural Minimalism
The aesthetic bridges Swiss graphic discipline and contemporary technical software ergonomics. It relies on crisp low-contrast delineations, purposeful semantic color pops, and a structured typographic cadence. Visual weight is maintained through typography and tonal stratification rather than heavy drop shadows or skeuomorphic styling.

## Colors

The color system enforces a rigorous functional taxonomy. Chromatic hues are reserved strictly for semantic feedback, interactive states, and telemetry markers, maintaining visual cleanliness.

### Surface & Neutral Architecture
- **Canvas Base (`#FFFFFF`):** High-clarity primary workspace canvas, maximizing text-to-ground contrast.
- **Subtle Surface (`#F8FAFC`):** Porcelain ground for sidebars, grouped cards, table headers, and structural wells.
- **Dividers & Outlines (`#E2E8F0`):** Soft slate boundaries that define clear spatial architecture without visual clutter.
- **Muted Borders (`#CBD5E1`):** Applied to active input fields, hover boundaries, and selected states.
- **Deep Slate Base (`#0F172A`):** Dominant ink tone for headers, active values, and primary body copy, achieving WCAG AAA contrast ratios.
- **Secondary Slate (`#475569`):** Subordinate value for metadata, table column headers, and secondary context.
- **De-emphasized Slate (`#94A3B8`):** Restrained tone for placeholders, disabled typography, and passive iconography.

### Semantic & Accent Spectrum
- **Brand / Active Indigo-Cyan (`#0284C7`):** Primary interactions, focused states, interactive tabs, and system navigation links.
- **Verified / Operational Emerald (`#10B981`):** Complete operations, verified identities, healthy telemetry, and balance positive markers.
- **Warning / In-Prep Warm Amber (`#F59E0B`):** Queued items, pending operations, rate warning states, and cautious thresholds.
- **Alert / Destructive Crimson (`#EF4444`):** System errors, critical halts, hard validation rejects, and irreversible operations.

## Typography

The type system is powered by Inter, optimized for screen clarity, uniform stroke weights, and tall x-height. Numerical readouts, IDs, and tabular figures should utilize tabular lining figures (`font-variant-numeric: tabular-nums`) to preserve column alignment across real-time updates.

### Usage Directives
- **Headlines:** Use tight letter spacing to keep display scale titles grounded and cohesive.
- **Labels (`label-sm`):** Rendered in uppercase with widened tracking (`0.04em`) when applied to micro-headers, data table categorization, and metadata caps.
- **Code Figures (`code-sm`):** JetBrains Mono is assigned to raw data payloads, API strings, hashes, and machine outputs for immediate distinction from prose.

## Layout & Spacing

The spatial architecture is calibrated to an 8-point base rhythm, supplemented with a 4-point micro-step for tight toolbars and data-dense rows.

### Breakpoints & Adaptive Layout
- **Mobile (< 768px):** Single-column layout. Margin default is `1rem` (`margin`), gutter is `1rem` (`gutter`). Action drawers substitute popovers. Toolbars stack vertically.
- **Tablet (768px - 1024px):** 6-column fluid grid. Outer margin expands to `1.5rem` (`margin-md`). Navigation condenses to an icon-rail.
- **Desktop (1025px+):** 12-column layout with a maximum container bounding box of `1440px`. Margin scales to `2.5rem` (`margin-lg`), and intra-column gutter settles at `1.5rem` (`gutter-lg`).

### Spacing Application
- Use `space-xs` (4px) and `space-sm` (8px) for inline micro-gaps (e.g., icon-to-label pairs, badge internal insets).
- Use `space-md` (12px) and `space-lg` (16px) for interior card padding, segmented controls, and compact list items.
- Use `space-xl` (24px) through `space-3xl` (48px) exclusively for major module separation and visual section breaks.

## Elevation & Depth

Spatial layering relies on flat, surface-container contrast and precise low-contrast borders rather than heavy atmospheric drop shadows.

### Elevation Hierarchy
- **Level 0 (Flat Ground):** `#FFFFFF` or `#F8FAFC` base background. Zero shadow. Partitioned purely through `1px solid #E2E8F0` structural line work.
- **Level 1 (Card & Modular Panes):** `#FFFFFF` resting against a `#F8FAFC` canvas. Defined by `1px solid #E2E8F0` paired with an ultra-faint settling shadow: `box-shadow: 0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Level 2 (Hover Targets & Flyouts):** Used for interactive cards on pointer hover and persistent menus: `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modals, Overlays & Drawers):** High-priority contextual dialogs floating above a canvas dimming layer (`rgba(15, 23, 42, 0.4)`): `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`. Border remains active at `1px solid #CBD5E1`.

## Shapes

The design uses soft, measured corner rounding (`roundedness: 1`). Radii stay tight and geometric to mirror technical instrumentation and maintain sharp grid alignment.

### Geometry Standards
- **Core Elements (Inputs, Buttons, Badges):** `4px` (`0.25rem`). Clean, precise perimeter edges with minimal optical distortion.
- **Mid-Tier Structures (Cards, Dialogs, Dropdowns):** `8px` (`0.5rem`, `rounded-lg`). Softens spatial containers without losing structured alignment.
- **High-Tier Elements (Outer App Shells, Modals):** `12px` (`0.75rem`, `rounded-xl`).
- **Circular Utilities (Avatars, Status Indicator Dots):** Fully rounded `9999px`.

## Components

### Buttons
- **Primary:** Solid `#0284C7` background, `#FFFFFF` text, `4px` radius. Hover: `#0369A1`. Active: `#075985`. Focus: Ring `2px` offset with `#0284C7`.
- **Secondary / Outline:** Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`. Hover: Background `#F8FAFC`, border `#CBD5E1`.
- **Ghost:** Transparent background, text `#475569`. Hover: `#F1F5F9`, text `#0F172A`.
- **Destructive:** Background `#EF4444`, text `#FFFFFF`. Hover: `#DC2626`.
- **Sizing:** Standard input match at `36px` height; compact table-density variant at `28px` height.

### Input Fields & Controls
- **Text Inputs:** Height `36px`, background `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `4px`, padding `0 12px`. Text `#0F172A`, placeholder `#94A3B8`. Active focus: Border `#0284C7`, box-shadow `0 0 0 1px #0284C7`.
- **Checkboxes & Radios:** `16px x 16px`. Default: Border `1.5px solid #CBD5E1`, background `#FFFFFF`. Selected: Background `#0284C7`, border `#0284C7` with crisp white check/pip icon.

### Status Chips & Badges
- **General Architecture:** Inset padding `2px 8px`, height `20px`, typography `label-sm`, rounded `4px`.
- **Verified / Ready:** Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`.
- **Warning / In-Prep:** Background `#FFFBEB`, text `#92400E`, border `1px solid #FDE68A`.
- **Alert / Critical:** Background `#FEF2F2`, text `#991B1B`, border `1px solid #FECACA`.
- **Neutral / Idle:** Background `#F1F5F9`, text `#334155`, border `1px solid #E2E8F0`.

### Data Cards & Data Tables
- **Cards:** Background `#FFFFFF`, border `1px solid #E2E8F0`, radius `8px`, header separator line `1px solid #F1F5F9`.
- **Tables:** Outer container wrapped in `1px solid #E2E8F0`. Header row background `#F8FAFC`, uppercase `label-sm` text in `#475569`. Row borders `1px solid #F1F5F9`. Row hover state `#F8FAFC` transition speed `150ms`.

### Metric Displays & Telemetry Tickers
- Structured numeric component pairing a `label-sm` category descriptor over an extra-bold `headline-md` value with tabular font configuration. Micro status indicators display trending deltas (`+2.4%`) utilizing the verified emerald or alert crimson tokens.